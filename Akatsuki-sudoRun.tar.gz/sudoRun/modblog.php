<html>
<body>
<button><a href=requests.php> See Pull Requests<a></button> <p>
<button><a href=dbview.php> View WriteUp DataBase</button></a>
</p></body>
<style>
body{
	margin: 0 auto;
	font-family: sans-serif;
}
button{
	padding: 10px;
	margin: 2px;
	font-size: 25 px;
	align: center;
}
</style>
</html>
